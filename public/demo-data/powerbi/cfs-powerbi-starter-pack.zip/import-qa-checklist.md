# Import QA Checklist

- [ ] Seven CSV tables imported with headers.
- [ ] Numeric columns use decimal/whole-number types.
- [ ] Blank numeric values remain blank.
- [ ] Scenario and geography relationships are many-to-one, single direction.
- [ ] Geography and scenario dimension keys are unique.
- [ ] Row counts match provenance.json.
- [ ] Special assets are isolated before comparison.
- [ ] Demo/local source label matches the active CFS runtime.
- [ ] No owner, contact, credential, or probability fields are present.
