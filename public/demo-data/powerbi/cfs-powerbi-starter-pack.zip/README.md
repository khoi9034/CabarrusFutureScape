# CFS Economics Power BI Starter Pack

Source: Portfolio demonstration data
Generated: 2026-07-31T02:47:35.078231-04:00
Schema version: 1.0

1. Extract the ZIP without renaming the csv folder.
2. Open Power BI Desktop and import the seven CSV files.
3. Apply the relationships in relationships.json as single-direction many-to-one.
4. Paste the measures from dax-measures.dax only after checking numeric column types.
5. Complete import-qa-checklist.md before publishing.

Blank values are missing data, not zeros. CFS Economics is screening-level context, not an appraisal, tax bill, or fiscal impact study.