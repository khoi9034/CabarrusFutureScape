# Recommended Report Pages

1. Executive Economic Dashboard: KPI cards, opportunity classes, and data confidence.
2. Parcel Investment Screen: segment, geography, opportunity, and special-asset slicers.
3. Scenario Planning Model: scenario matrix with the disconnected scenario model.
4. Data Confidence Register: readiness status and next-data-need table.

Keep scenario tables disconnected from parcel signals unless a validated business key is added. Compare value-per-acre measures within comparable economic segments.
